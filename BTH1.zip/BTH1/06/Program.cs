﻿using System;
using System.Text;

namespace _06
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.Unicode;
            Console.Write("  Số hàng của ma trận: ");
            int m = int.Parse(Console.ReadLine());
            Console.Write("  Số cột của ma trận: ");
            int n = int.Parse(Console.ReadLine());
            while (m <= 0 && n <= 0 || m * n < 0)
            {
                Console.Clear();
                Console.WriteLine("Không tồn tại ma trận để thực hiện tiếp, vui lòng nhập lại");
                Main(args);
            }
            int[,] matrix = new int[m, n];
            matrixImport(m, n, matrix);
            choose(ref m, ref n, matrix);
        }
        static void menu()
        {
            Console.WriteLine("-------------------------------------------------------");
            Console.WriteLine("  (1) Xuất ma trận");
            Console.WriteLine("  (2) Tìm phần tử lớn nhất và nhỏ nhất");
            Console.WriteLine("  (3) Tìm dòng có tổng lớn nhất");
            Console.WriteLine("  (4) Tính tổng các số không phải là số nguyên tố");
            Console.WriteLine("  (5) Xóa dòng thứ k trong ma trận");
            Console.WriteLine("  (6) Xóa cột chứa phần tử lớn nhất trong ma trận");
            Console.WriteLine("-------------------------------------------------------");
        }
        static void choose(ref int row, ref int collum, int[,] matrix)
        {
            menu();
            Console.Write("   Lựa chọn của bạn là: ");
            int choice = int.Parse(Console.ReadLine());
            Console.Clear();
            switch (choice)
            {
                case 1:
                    matrixExport(row, collum, matrix);
                    choose(ref row, ref collum, matrix);
                    break;
                case 2:
                    Console.WriteLine(" Phần tử lớn nhất và nhỏ nhất lần lượt là {0} và {1}", getMax(row, collum, matrix), getMin(row, collum, matrix));
                    choose(ref row, ref collum, matrix);
                    break;
                case 3:
                    Console.Write(" (Những) Dòng có tổng lớn nhất mang chỉ số ");
                    getMaxRows(row, collum, matrix);
                    choose(ref row, ref collum, matrix);
                    break;
                case 4:
                    Console.WriteLine(" Tổng các số không phải số nguyên tố là " + notPrimeTotal(row, collum, matrix));
                    choose(ref row, ref collum, matrix);
                    break;
                case 5:
                    deleteRow(ref row, collum, matrix);
                    choose(ref row, ref collum, matrix);
                    break;
                case 6:
                    deleteMaxValueCollum(row, ref collum, matrix);
                    choose(ref row, ref collum, matrix);
                    break;
                default:
                    Console.WriteLine(" Lựa chọn không tồn tại");
                    choose(ref row, ref collum, matrix);
                    break;
            }
        }
        static void matrixImport(int row, int collum, int[,] matrix){
            Console.Clear();
            Random random = new Random();
            for (int i = 0; i < row; i++)
                for (int j = 0; j < collum; j++)  {
                    matrix[i, j] = random.Next(0, 10);
                }
            Console.WriteLine("  Tạo mảng thành công!");
        }
        static void matrixExport(int row, int collum, int[,] matrix) {
            for (int i = 0; i < row; i++) {
                Console.Write("  ");
                for (int j = 0; j < collum; j++)
                    Console.Write(matrix[i,j] + " ");
                Console.WriteLine();
            }
        }
        static int getMax(int row, int collum, int[,] matrix) {
            int max = matrix[0, 0];
            for (int i = 0; i < row; i++)
                for (int j = 0; j < collum; j++)
                    if (matrix[i, j] > max)
                        max = matrix[i, j];
            return max;
        }
        static int getMin(int row, int collum, int[,] matrix) {
            int min = matrix[0, 0];
            for (int i = 0; i < row; i++)
                for (int j = 0; j < collum; j++)
                    if (matrix[i, j] < min)
                        min = matrix[i, j];
            return min;
        }
        static void getMaxRows(int row, int collum, int[,] matrix) {
            int rowTotal(int r) {
                int total = 0;
                for (int i = 0; i < row; i++)
                    if (i == r)
                    {
                        for (int j = 0; j < collum; j++)
                            total += matrix[i, j];
                        break;
                    }
                return total;
            }
            int maxTotalIndex = 0;
            for (int i = 0; i < row; i++)
                if (rowTotal(i) > rowTotal(maxTotalIndex))
                    maxTotalIndex = i;
            for (int i = 0; i < row; i++)
                if (rowTotal(i) == rowTotal(maxTotalIndex))
                    Console.Write(i + " ");
            Console.WriteLine();
        }
        static int notPrimeTotal(int row, int collum, int[,] matrix){
            // Prime check
            bool isPrime(int x) {
                if (x < 2)
                    return false;
                for (int i = 2; i < x - 1; i++)
                    if (x % 2 == 0)
                        return false;
                return true;
            }

            int total = 0;
            for (int i = 0; i < row; i++)
                for (int j = 0; j < collum; j++)
                    if (!isPrime(matrix[i, j]))
                        total += matrix[i, j];
            return total;
        }
        static void deleteRow(ref int row, int collum, int[,] matrix) {
            Console.Write(" Dòng muốn xóa là ");
            int k = int.Parse(Console.ReadLine());
            Console.Clear();
            if (k > row || k < 0)
                Console.WriteLine(" Dòng thứ {0} không tồn tại", k);
            else
            {
                if (k == row)
                    row--;
                else
                {
                    for (int i = k; i < row - 1; i++)
                        for (int j = 0; j < collum; j++)
                            matrix[i, j] = matrix[i + 1, j];
                    row--;
                }
                Console.WriteLine(" Đã xóa dòng thứ {0}", k);
            }
        }
        static void deleteMaxValueCollum(int row, ref int collum, int[,] matrix) {

            int getMaxValueCollum(int row, int collum, int[,] matrix){
                for (int i = 0; i < row; i++)
                    for (int j = 0; j < collum; j++)
                        if (getMax(row, collum, matrix) == matrix[i, j])
                            return j;
                return -1;
            }

            if (getMaxValueCollum(row, collum, matrix) == collum)
                collum--;
            else
            {
                int maxTemp = getMax(row, collum, matrix);
                while (maxTemp == getMax(row, collum, matrix))  
                {
                    for (int i = getMaxValueCollum(row, collum, matrix); i < collum - 1; i++)
                        for (int j = 0; j < row; j++)
                            matrix[j, i] = matrix[j, i + 1];
                    collum--;
                }
            }
            Console.WriteLine(" Xóa hoàn tất");
        }
    }
}
