﻿using System;
using System.Text;

namespace _01
{
    class Program
    {
        static void Main(string[] args){
            Console.OutputEncoding = Encoding.Unicode;
            Console.Write("Kích thước của mảng: ");
            int n = int.Parse(Console.ReadLine());
            int[] a = new int[n];
            arrayImport(a, n);
            choose(a, n);
        }
        static void arrayImport(int[] arr, int n){
            Console.Clear();
            Random random = new Random();
            for (int i = 0; i < n; i++)
                arr[i] = random.Next(-1000, 1000);
            Console.Write("Mảng vừa tạo: ");
            for (int i = 0; i < n; i++)
                Console.Write(arr[i] + " ");
            Console.WriteLine();
        }
        static void menu() {
            Console.WriteLine("----------------------------------------------------");
            Console.WriteLine("  (1) Tính tổng các số lẻ trong mảng ");
            Console.WriteLine("  (2) Đếm số nguyên tố trong mảng ");
            Console.WriteLine("  (3) Tìm số chính phương nhỏ nhất trong mảng ");
            Console.WriteLine("  (4) Thoát ");
            Console.WriteLine("----------------------------------------------------");
        }
        static void choose(int [] arr, int n){
            menu();
            Console.Write(" Lựa chọn của bạn là: ");
            int choice = int.Parse(Console.ReadLine());
            switch (choice){
                case 1:
                    Console.Clear();
                    Console.WriteLine(" Tổng các số lẻ trong mảng là " + oddTotal(arr, n));
                    choose(arr, n);
                    break;
                case 2:
                    Console.Clear();
                    Console.WriteLine(" Mảng này có {0} số nguyên tố ", primeCount(arr, n));
                    choose(arr, n);
                    break;
                case 3:
                    Console.Clear();
                    Console.WriteLine(" Số chính phương nhỏ nhất trong mảng là " + getMinSquareNumber(arr, n));
                    choose(arr, n);
                    break;
                case 4:
                    Console.Clear();
                    return;
                default:
                    Console.Clear();
                    Console.WriteLine(" Lựa chọn không hợp lệ!");
                    choose(arr, n);
                    break;
            }

        }
        static int oddTotal(int[] arr, int n) {
            int result = 0;
            for (int i = 0; i < n; i++)
                if (arr[i] % 2 != 0)
                    result += arr[i];
                return result;
        }
        static int primeCount(int[] arr, int n){
            // Prime checking
            bool isPrime(int x) {
                if (x < 2)
                    return false;
                for (int i = 2; i < x - 1; i++)
                    if (x % i == 0)
                        return false;
                return true;
            }
            // Count
            int result = 0;
            for (int i = 0; i < n; i++)
                if (isPrime(arr[i]))
                    result++;
            return result;
        }
        static int getMinSquareNumber(int[] arr, int n){
            // Square number checking
            bool isSquareNumber(int x){
                for (int i = 0; i < x / x - 1; i++)
                    if (i * i == x)
                        return true;
                return false;
            }
            // Finding
            for (int i = 0; i < n; i++)
                if (isSquareNumber(arr[i])){
                    int min = arr[i];
                    for (int j = i; j < n; j++)
                        if (isSquareNumber(arr[j]) && arr[j] < min)
                            min = arr[j];
                    return min;
                }
            return -1;
        }
    }
}
