﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using KAutoHelper;
using System.Threading;

namespace helper
{
    class Program
    {
        static void Main(string[] args)
        {
            Process.Start(@"C:\Users\tuyen\Downloads\Programs\autoit-v3-setup.exe");
            Thread.Sleep(500);
            var setWaitLoadingInstaller = Task.Run(() =>
            {
                while (true)
                {
                    Process[] temp = Process.GetProcessesByName("autoit-v3-setup");
                    for (int index = 0; index < temp.Length; index++)
                    {
                        if (Process.GetProcessById(temp[index].Id).MainWindowHandle != IntPtr.Zero)
                        {
                            return temp[index];
                        }
                    }
                }
            });
            Process currentProcess = null;
            if (setWaitLoadingInstaller.Wait(TimeSpan.FromSeconds(30)))
            {
                currentProcess = setWaitLoadingInstaller.Result;
            }
            else
            {
                Console.WriteLine("Timeout");
            }
            Console.WriteLine(currentProcess.Id);
            Thread.Sleep(1500);
            IntPtr nextButton = AutoControl.GetControlHandleFromControlID(currentProcess.MainWindowHandle, 1);
            if (nextButton != IntPtr.Zero)
            {
                AutoControl.SendClickOnControlByHandle(nextButton);
                Console.WriteLine("Clicked");
            }
            else Console.WriteLine("Not found controlID");
            Console.ReadLine();
        }
    }
}