﻿using System;

namespace _05
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write(" - Date: ");
            int date = int.Parse(Console.ReadLine());
            Console.Write(" - Month: ");
            int month = int.Parse(Console.ReadLine());
            Console.Write(" - Year: ");
            int year = int.Parse(Console.ReadLine());
            if (isYear(year) && isMonth(month) && isDate(date, month, year)){
                DateTime t = new DateTime(date, month, year);
                Console.WriteLine("  {0}/{1}/{2} is {3}", date, month, year, t.DayOfWeek.ToString());
            }
            else Console.WriteLine(" {0}/{1}/{2} is invalid", date, month, year);
        }
        static bool isYear(int x)
        {
            if (x < 1)
                return false;
            return true;
        }
        static bool isMonth(int x)
        {
            if (x < 1 || x > 12)
                return false;
            return true;
        }
        static bool isDate(int x, int month, int year)
        {
            if (x < 1 || x > DateTime.DaysInMonth(year, month))
                return false;
            return true;
        }


    }
}
