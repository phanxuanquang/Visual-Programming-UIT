﻿using System;
using System.Text;

namespace _04
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.Unicode;
            Console.Write(" - Tháng: ");
            int month = int.Parse(Console.ReadLine());
            Console.Write(" - Năm: ");
            int year = int.Parse(Console.ReadLine());
            if (isYear(year) && isMonth(month))
                Console.WriteLine("Tháng {0} năm {1} có {2} ngày", month, year, DateTime.DaysInMonth(year, month));
            else Console.WriteLine("Tháng {0} năm {1} không hợp lệ", month, year);
        }
        static bool isYear(int x)
        {
            if (x < 1)
                return false;
            return true;
        }
        static bool isMonth(int x)
        {
            if (x < 1 || x > 12)
                return false;
            return true;
        }
    }
}
